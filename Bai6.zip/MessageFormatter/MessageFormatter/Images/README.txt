Đặt file hình CD của bạn vào đây, ví dụ: cd_big.png, cd_small.png
