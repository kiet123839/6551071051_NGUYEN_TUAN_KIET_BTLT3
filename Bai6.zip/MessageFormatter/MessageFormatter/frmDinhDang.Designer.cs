namespace MessageFormatter
{
    partial class frmDinhDang
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);

            this.grpInput = new System.Windows.Forms.GroupBox();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.lblMessageCaption = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblNameCaption = new System.Windows.Forms.Label();

            this.grpColor = new System.Windows.Forms.GroupBox();
            this.radBlack = new System.Windows.Forms.RadioButton();
            this.radBlue = new System.Windows.Forms.RadioButton();
            this.radGreen = new System.Windows.Forms.RadioButton();
            this.radRed = new System.Windows.Forms.RadioButton();

            this.chkVisible = new System.Windows.Forms.CheckBox();

            this.picBig = new System.Windows.Forms.PictureBox();
            this.picSmall = new System.Windows.Forms.PictureBox();

            this.grpAction = new System.Windows.Forms.GroupBox();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();

            this.lblMessage = new System.Windows.Forms.Label();

            this.grpInput.SuspendLayout();
            this.grpColor.SuspendLayout();
            this.grpAction.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBig)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSmall)).BeginInit();
            this.SuspendLayout();

            //
            // grpInput
            //
            this.grpInput.Text = "Input Name && Message";
            this.grpInput.Location = new System.Drawing.Point(12, 12);
            this.grpInput.Size = new System.Drawing.Size(560, 110);
            this.grpInput.TabIndex = 0;
            this.grpInput.TabStop = false;
            this.grpInput.Controls.Add(this.lblNameCaption);
            this.grpInput.Controls.Add(this.txtName);
            this.grpInput.Controls.Add(this.lblMessageCaption);
            this.grpInput.Controls.Add(this.txtMessage);

            //
            // lblNameCaption
            //
            this.lblNameCaption.AutoSize = true;
            this.lblNameCaption.Location = new System.Drawing.Point(20, 30);
            this.lblNameCaption.Text = "Name:";

            //
            // txtName
            //
            this.txtName.Location = new System.Drawing.Point(110, 27);
            this.txtName.Size = new System.Drawing.Size(420, 20);
            this.txtName.TabIndex = 1;
            this.txtName.BackColor = System.Drawing.Color.PeachPuff;

            //
            // lblMessageCaption
            //
            this.lblMessageCaption.AutoSize = true;
            this.lblMessageCaption.Location = new System.Drawing.Point(20, 68);
            this.lblMessageCaption.Text = "Message:";

            //
            // txtMessage
            //
            this.txtMessage.Location = new System.Drawing.Point(110, 65);
            this.txtMessage.Size = new System.Drawing.Size(420, 20);
            this.txtMessage.TabIndex = 2;
            this.txtMessage.BackColor = System.Drawing.Color.PeachPuff;

            //
            // grpColor
            //
            this.grpColor.Text = "Color";
            this.grpColor.Location = new System.Drawing.Point(12, 132);
            this.grpColor.Size = new System.Drawing.Size(150, 190);
            this.grpColor.TabIndex = 3;
            this.grpColor.TabStop = false;
            this.grpColor.Controls.Add(this.radRed);
            this.grpColor.Controls.Add(this.radGreen);
            this.grpColor.Controls.Add(this.radBlue);
            this.grpColor.Controls.Add(this.radBlack);

            //
            // radRed
            //
            this.radRed.Text = "Red";
            this.radRed.ForeColor = System.Drawing.Color.Red;
            this.radRed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.radRed.Location = new System.Drawing.Point(20, 30);
            this.radRed.AutoSize = true;
            this.radRed.TabIndex = 4;
            this.radRed.CheckedChanged += new System.EventHandler(this.radColor_CheckedChanged);

            //
            // radGreen
            //
            this.radGreen.Text = "Green";
            this.radGreen.ForeColor = System.Drawing.Color.Green;
            this.radGreen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.radGreen.Location = new System.Drawing.Point(20, 70);
            this.radGreen.AutoSize = true;
            this.radGreen.TabIndex = 5;
            this.radGreen.CheckedChanged += new System.EventHandler(this.radColor_CheckedChanged);

            //
            // radBlue
            //
            this.radBlue.Text = "Blue";
            this.radBlue.ForeColor = System.Drawing.Color.Blue;
            this.radBlue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.radBlue.Location = new System.Drawing.Point(20, 110);
            this.radBlue.AutoSize = true;
            this.radBlue.TabIndex = 6;
            this.radBlue.CheckedChanged += new System.EventHandler(this.radColor_CheckedChanged);

            //
            // radBlack
            //
            this.radBlack.Text = "Black";
            this.radBlack.ForeColor = System.Drawing.Color.Black;
            this.radBlack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.radBlack.Location = new System.Drawing.Point(20, 150);
            this.radBlack.AutoSize = true;
            this.radBlack.TabIndex = 7;
            this.radBlack.CheckedChanged += new System.EventHandler(this.radColor_CheckedChanged);

            //
            // chkVisible
            //
            this.chkVisible.Text = "Message Visible";
            this.chkVisible.Location = new System.Drawing.Point(178, 132);
            this.chkVisible.AutoSize = true;
            this.chkVisible.TabIndex = 8;
            this.chkVisible.CheckedChanged += new System.EventHandler(this.chkVisible_CheckedChanged);

            //
            // picBig (hình CD lớn - nằm dưới, hiện ra ban đầu)
            //
            this.picBig.Location = new System.Drawing.Point(190, 160);
            this.picBig.Size = new System.Drawing.Size(120, 120);
            this.picBig.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBig.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBig.TabIndex = 10;
            this.picBig.TabStop = false;
            this.picBig.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picBig.Click += new System.EventHandler(this.picBig_Click);

            //
            // picSmall (hình CD nhỏ - nằm chồng lên trên, đồng tâm với picBig, ban đầu ẩn)
            //
            this.picSmall.Location = new System.Drawing.Point(215, 172);
            this.picSmall.Size = new System.Drawing.Size(70, 70);
            this.picSmall.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSmall.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picSmall.TabIndex = 9;
            this.picSmall.TabStop = false;
            this.picSmall.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picSmall.Click += new System.EventHandler(this.picSmall_Click);

            //
            // grpAction
            //
            this.grpAction.Text = "Action";
            this.grpAction.Location = new System.Drawing.Point(422, 132);
            this.grpAction.Size = new System.Drawing.Size(150, 190);
            this.grpAction.TabIndex = 11;
            this.grpAction.TabStop = false;
            this.grpAction.Controls.Add(this.btnDisplay);
            this.grpAction.Controls.Add(this.btnClear);
            this.grpAction.Controls.Add(this.btnExit);

            //
            // btnDisplay
            //
            this.btnDisplay.Text = "&Display";
            this.btnDisplay.Location = new System.Drawing.Point(25, 30);
            this.btnDisplay.Size = new System.Drawing.Size(100, 35);
            this.btnDisplay.TabIndex = 12;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);

            //
            // btnClear
            //
            this.btnClear.Text = "&Clear";
            this.btnClear.Location = new System.Drawing.Point(25, 78);
            this.btnClear.Size = new System.Drawing.Size(100, 35);
            this.btnClear.TabIndex = 13;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);

            //
            // btnExit
            //
            this.btnExit.Text = "E&xit";
            this.btnExit.Location = new System.Drawing.Point(25, 126);
            this.btnExit.Size = new System.Drawing.Size(100, 35);
            this.btnExit.TabIndex = 14;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);

            //
            // lblMessage (label hiển thị kết quả, nằm ở thanh dưới cùng)
            //
            this.lblMessage.Location = new System.Drawing.Point(12, 332);
            this.lblMessage.Size = new System.Drawing.Size(560, 30);
            this.lblMessage.BackColor = System.Drawing.Color.MistyRose;
            this.lblMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblMessage.TabIndex = 15;

            //
            // toolTip1
            //
            this.toolTip1.SetToolTip(this.picBig, "Click Me");
            this.toolTip1.SetToolTip(this.picSmall, "Click Me");

            //
            // frmDinhDang
            //
            this.ClientSize = new System.Drawing.Size(584, 374);
            this.Text = "Message Formater";
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.AcceptButton = this.btnDisplay;
            this.CancelButton = this.btnExit;

            this.Controls.Add(this.grpInput);
            this.Controls.Add(this.grpColor);
            this.Controls.Add(this.chkVisible);
            this.Controls.Add(this.picBig);
            this.Controls.Add(this.picSmall);
            this.Controls.Add(this.grpAction);
            this.Controls.Add(this.lblMessage);

            this.Load += new System.EventHandler(this.frmDinhDang_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmDinhDang_FormClosing);

            this.grpInput.ResumeLayout(false);
            this.grpInput.PerformLayout();
            this.grpColor.ResumeLayout(false);
            this.grpColor.PerformLayout();
            this.grpAction.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picBig)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSmall)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;

        private System.Windows.Forms.GroupBox grpInput;
        private System.Windows.Forms.Label lblNameCaption;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblMessageCaption;
        private System.Windows.Forms.TextBox txtMessage;

        private System.Windows.Forms.GroupBox grpColor;
        private System.Windows.Forms.RadioButton radRed;
        private System.Windows.Forms.RadioButton radGreen;
        private System.Windows.Forms.RadioButton radBlue;
        private System.Windows.Forms.RadioButton radBlack;

        private System.Windows.Forms.CheckBox chkVisible;

        private System.Windows.Forms.PictureBox picBig;
        private System.Windows.Forms.PictureBox picSmall;

        private System.Windows.Forms.GroupBox grpAction;
        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;

        private System.Windows.Forms.Label lblMessage;
    }
}
