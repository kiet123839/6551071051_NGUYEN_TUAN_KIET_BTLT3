using System;
using System.Drawing;
using System.Windows.Forms;

namespace MessageFormatter
{
    public partial class frmDinhDang : Form
    {
        public frmDinhDang()
        {
            InitializeComponent();
        }

        // 1. Sự kiện Load của Form
        private void frmDinhDang_Load(object sender, EventArgs e)
        {
            // Mặc định chọn radio Red
            radRed.Checked = true;

            // Con trỏ đặt tại ô Name
            txtName.Focus();

            // Mặc định check Message Visible
            chkVisible.Checked = true;

            // 2 hình CD chồng lên nhau đồng tâm:
            // hình lớn hiện, hình nhỏ ẩn
            picBig.Visible = true;
            picSmall.Visible = false;
        }

        // 2. Nhấn Display (hoặc Enter vì đây là AcceptButton)
        private void btnDisplay_Click(object sender, EventArgs e)
        {
            lblMessage.Text = txtName.Text + " : " + txtMessage.Text;
        }

        // 3. Nhấn Clear
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtMessage.Clear();
            txtName.Clear();
            txtName.Focus();
        }

        // 4. Chọn RadioButton -> đổi màu chữ của lblMessage
        private void radColor_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rad = sender as RadioButton;
            if (rad == null || !rad.Checked) return;

            if (rad == radRed)
                lblMessage.ForeColor = Color.Red;
            else if (rad == radGreen)
                lblMessage.ForeColor = Color.Green;
            else if (rad == radBlue)
                lblMessage.ForeColor = Color.Blue;
            else if (rad == radBlack)
                lblMessage.ForeColor = Color.Black;
        }

        // 5. Ẩn/hiện lblMessage theo chkVisible
        private void chkVisible_CheckedChanged(object sender, EventArgs e)
        {
            lblMessage.Visible = chkVisible.Checked;
        }

        // 6. Nhấn Exit (hoặc Esc vì đây là CancelButton) -> đóng chương trình
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // 7. Xác nhận trước khi đóng Form
        private void frmDinhDang_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc bạn muốn đóng ứng dụng?", "Thông báo!",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
            if (dl == DialogResult.No)
                e.Cancel = true;
        }

        // 8. Click vào hình CD lớn -> ẩn hình lớn, hiện hình nhỏ
        private void picBig_Click(object sender, EventArgs e)
        {
            picBig.Visible = false;
            picSmall.Visible = true;
        }

        // Click vào hình CD nhỏ -> ẩn hình nhỏ, hiện hình lớn
        private void picSmall_Click(object sender, EventArgs e)
        {
            picSmall.Visible = false;
            picBig.Visible = true;
        }
    }
}
