# Bài 6 – Message Formatter (Windows Forms - C#)

## Cách mở project
1. Giải nén file zip.
2. Mở file `MessageFormatter.sln` bằng **Visual Studio** (2019/2022, có cài workload ".NET desktop development").
3. Nhấn **F5** để chạy chương trình (Debug > Start).

Project dùng target `.NET Framework 4.7.2` (WinForms), tương thích với Visual Studio hiện đại lẫn các máy đã cài .NET Framework.

## Cấu trúc project
```
MessageFormatter.sln
MessageFormatter/
 ├─ MessageFormatter.csproj
 ├─ Program.cs                 (điểm khởi động Main)
 ├─ frmDinhDang.cs              (code xử lý sự kiện - logic chính)
 ├─ frmDinhDang.Designer.cs     (khai báo control, vị trí, TabIndex, ToolTip)
 └─ Images/                     (chỗ để bạn bỏ 2 hình CD vào)
```

## Việc bạn cần làm thêm: gắn hình ảnh CD
Vì đề bài dùng hình CDRom (Mac OS Leopard) không có sẵn để phân phối, project đã dựng sẵn
2 PictureBox (`picBig`, `picSmall`) chồng lên nhau đồng tâm, nhưng **chưa gắn ảnh**. Để gắn ảnh:

1. Copy 2 file ảnh CD của bạn vào thư mục `MessageFormatter/Images/` (ví dụ `cd_big.png`, `cd_small.png`).
2. Mở `frmDinhDang.Designer.cs`, tìm dòng khai báo `picBig` và `picSmall`, thêm:
   ```csharp
   this.picBig.Image = global::MessageFormatter.Properties.Resources... 
   ```
   Cách đơn giản hơn: trong Visual Studio, chọn `picBig` trên giao diện Designer → cửa sổ Properties →
   thuộc tính `Image` → **Import...** → chọn file ảnh. Làm tương tự cho `picSmall`.
3. Trong `MessageFormatter.csproj`, bỏ ghi chú (uncomment) 2 dòng `<None Include="Images\...">` để ảnh
   được copy ra thư mục build (nếu bạn load ảnh bằng đường dẫn thay vì Resource).
4. Sau khi gắn ảnh, chỉnh lại `Location`/`Size` của `picSmall` trong Designer (kéo thả bằng chuột hoặc
   sửa số) để 2 hình đồng tâm chính xác như đề bài yêu cầu (mục 9).

## Các chức năng đã cài đặt theo đúng yêu cầu đề bài

| # | Yêu cầu | Đã cài đặt ở |
|---|---------|--------------|
| 1 | Form Load: focus vào `txtName`, chọn `radRed`, check `chkVisible`, 2 hình CD đồng tâm (hình lớn hiện, hình nhỏ ẩn) | `frmDinhDang_Load` |
| 2 | ToolTip "Click Me" khi rê chuột vào `picBig`/`picSmall` | `toolTip1.SetToolTip(...)` trong Designer |
| 3 | TabIndex hợp lý: Name(1) → Message(2) → Color(4-7) → Visible(8) → picSmall/picBig(9-10) → Action(12-14) | Đã gán trong Designer |
| 4 | `btnDisplay` / phím Enter (`AcceptButton`) → gán `lblMessage.Text` | `btnDisplay_Click` |
| 5 | `btnClear` → xóa `txtName`, `txtMessage` | `btnClear_Click` |
| 6 | Chọn RadioButton màu → đổi `lblMessage.ForeColor` | `radColor_CheckedChanged` (dùng chung cho cả 4 radio) |
| 7 | `chkVisible` → ẩn/hiện `lblMessage` | `chkVisible_CheckedChanged` |
| 8 | `btnExit` / phím Esc (`CancelButton`) → `this.Close()` | `btnExit_Click` |
| 9 | Xác nhận trước khi đóng Form (Yes/No) | `frmDinhDang_FormClosing` |
| 10 | Click vào hình CD lớn/nhỏ → hoán đổi hiện/ẩn | `picBig_Click`, `picSmall_Click` |

## Ghi chú
- Trong bản gốc mỗi RadioButton có 1 hàm `_CheckedChanged` riêng (theo hướng dẫn double-click từng
  RadioButton). Ở đây mình gộp chung thành 1 hàm `radColor_CheckedChanged` dùng `sender` để kiểm tra
  radio nào được chọn — gọn hơn nhưng hoạt động y hệt, bạn có thể tách ra nếu thầy yêu cầu code riêng
  từng hàm.
