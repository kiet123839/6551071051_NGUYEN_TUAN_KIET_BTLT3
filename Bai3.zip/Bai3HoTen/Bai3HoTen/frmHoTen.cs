using System;
using System.Windows.Forms;

namespace Bai3HoTen
{
    public partial class frmHoTen : Form
    {
        public frmHoTen()
        {
            InitializeComponent();
        }

        // Nhấn Button "Họ Lót": gán nội dung txtHo cho lblHoTen
        private void btnHo_Click(object sender, EventArgs e)
        {
            lblHoTen.Text = txtHo.Text;
        }

        // Nhấn Button "Tên": gán nội dung txtTen cho lblHoTen
        private void btnTen_Click(object sender, EventArgs e)
        {
            lblHoTen.Text = txtTen.Text;
        }

        // Nhấn Button "Họ và Tên": gán nội dung txtHo + txtTen cho lblHoTen
        private void btnHoTen_Click(object sender, EventArgs e)
        {
            lblHoTen.Text = txtHo.Text + " " + txtTen.Text;
        }

        // Double click vào lblHoTen: xoá nội dung lblHoTen
        private void lblHoTen_DoubleClick(object sender, EventArgs e)
        {
            lblHoTen.Text = "";
        }

        // Nhấn Button "Thoát Chương Trình": đóng chương trình
        private void btnKetThuc_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
