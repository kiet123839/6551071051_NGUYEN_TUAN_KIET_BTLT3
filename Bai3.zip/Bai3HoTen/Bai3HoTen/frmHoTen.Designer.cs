namespace Bai3HoTen
{
    partial class frmHoTen
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblHoTen = new System.Windows.Forms.Label();
            this.lblHoLot = new System.Windows.Forms.Label();
            this.lblTen = new System.Windows.Forms.Label();
            this.txtHo = new System.Windows.Forms.TextBox();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.btnHo = new System.Windows.Forms.Button();
            this.btnTen = new System.Windows.Forms.Button();
            this.btnHoTen = new System.Windows.Forms.Button();
            this.btnKetThuc = new System.Windows.Forms.Button();
            this.SuspendLayout();
            //
            // lblHoTen
            //
            this.lblHoTen.BackColor = System.Drawing.Color.DodgerBlue;
            this.lblHoTen.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblHoTen.Location = new System.Drawing.Point(12, 12);
            this.lblHoTen.Name = "lblHoTen";
            this.lblHoTen.Size = new System.Drawing.Size(490, 60);
            this.lblHoTen.TabIndex = 0;
            this.lblHoTen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblHoTen.DoubleClick += new System.EventHandler(this.lblHoTen_DoubleClick);
            //
            // lblHoLot
            //
            this.lblHoLot.AutoSize = true;
            this.lblHoLot.Location = new System.Drawing.Point(30, 95);
            this.lblHoLot.Name = "lblHoLot";
            this.lblHoLot.Size = new System.Drawing.Size(45, 20);
            this.lblHoLot.TabIndex = 1;
            this.lblHoLot.Text = "Họ lót";
            //
            // lblTen
            //
            this.lblTen.AutoSize = true;
            this.lblTen.Location = new System.Drawing.Point(30, 135);
            this.lblTen.Name = "lblTen";
            this.lblTen.Size = new System.Drawing.Size(30, 20);
            this.lblTen.TabIndex = 2;
            this.lblTen.Text = "Tên";
            //
            // txtHo
            //
            this.txtHo.Location = new System.Drawing.Point(120, 92);
            this.txtHo.Name = "txtHo";
            this.txtHo.Size = new System.Drawing.Size(382, 27);
            this.txtHo.TabIndex = 3;
            //
            // txtTen
            //
            this.txtTen.BackColor = System.Drawing.Color.LightPink;
            this.txtTen.Location = new System.Drawing.Point(120, 132);
            this.txtTen.Name = "txtTen";
            this.txtTen.Size = new System.Drawing.Size(382, 27);
            this.txtTen.TabIndex = 4;
            //
            // btnHo
            //
            this.btnHo.Location = new System.Drawing.Point(30, 180);
            this.btnHo.Name = "btnHo";
            this.btnHo.Size = new System.Drawing.Size(120, 40);
            this.btnHo.TabIndex = 5;
            this.btnHo.Text = "Họ Lót";
            this.btnHo.UseVisualStyleBackColor = true;
            this.btnHo.Click += new System.EventHandler(this.btnHo_Click);
            //
            // btnTen
            //
            this.btnTen.Location = new System.Drawing.Point(191, 180);
            this.btnTen.Name = "btnTen";
            this.btnTen.Size = new System.Drawing.Size(120, 40);
            this.btnTen.TabIndex = 6;
            this.btnTen.Text = "Tên";
            this.btnTen.UseVisualStyleBackColor = true;
            this.btnTen.Click += new System.EventHandler(this.btnTen_Click);
            //
            // btnHoTen
            //
            this.btnHoTen.Location = new System.Drawing.Point(352, 180);
            this.btnHoTen.Name = "btnHoTen";
            this.btnHoTen.Size = new System.Drawing.Size(150, 40);
            this.btnHoTen.TabIndex = 7;
            this.btnHoTen.Text = "Họ và Tên";
            this.btnHoTen.UseVisualStyleBackColor = true;
            this.btnHoTen.Click += new System.EventHandler(this.btnHoTen_Click);
            //
            // btnKetThuc
            //
            this.btnKetThuc.Location = new System.Drawing.Point(150, 240);
            this.btnKetThuc.Name = "btnKetThuc";
            this.btnKetThuc.Size = new System.Drawing.Size(200, 40);
            this.btnKetThuc.TabIndex = 8;
            this.btnKetThuc.Text = "Thoát Chương Trình";
            this.btnKetThuc.UseVisualStyleBackColor = true;
            this.btnKetThuc.Click += new System.EventHandler(this.btnKetThuc_Click);
            //
            // frmHoTen
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(514, 302);
            this.Controls.Add(this.lblHoTen);
            this.Controls.Add(this.lblHoLot);
            this.Controls.Add(this.lblTen);
            this.Controls.Add(this.txtHo);
            this.Controls.Add(this.txtTen);
            this.Controls.Add(this.btnHo);
            this.Controls.Add(this.btnTen);
            this.Controls.Add(this.btnHoTen);
            this.Controls.Add(this.btnKetThuc);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmHoTen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bài Tập Họ Tên";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.Label lblHoLot;
        private System.Windows.Forms.Label lblTen;
        private System.Windows.Forms.TextBox txtHo;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.Button btnHo;
        private System.Windows.Forms.Button btnTen;
        private System.Windows.Forms.Button btnHoTen;
        private System.Windows.Forms.Button btnKetThuc;
    }
}
