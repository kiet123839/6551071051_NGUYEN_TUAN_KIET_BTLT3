namespace Bai1PasswordForm
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNhapPassword = new System.Windows.Forms.Label();
            this.txtPassWord = new System.Windows.Forms.TextBox();
            this.lblHienThiCaption = new System.Windows.Forms.Label();
            this.lblHienThi = new System.Windows.Forms.Label();
            this.btnHienThi = new System.Windows.Forms.Button();
            this.btnTiep = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.SuspendLayout();
            //
            // lblNhapPassword
            //
            this.lblNhapPassword.AutoSize = true;
            this.lblNhapPassword.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblNhapPassword.Location = new System.Drawing.Point(30, 30);
            this.lblNhapPassword.Name = "lblNhapPassword";
            this.lblNhapPassword.Size = new System.Drawing.Size(130, 20);
            this.lblNhapPassword.TabIndex = 0;
            this.lblNhapPassword.Text = "Nhập Password:";
            //
            // txtPassWord
            //
            this.txtPassWord.Location = new System.Drawing.Point(180, 27);
            this.txtPassWord.Name = "txtPassWord";
            this.txtPassWord.PasswordChar = '#';
            this.txtPassWord.Size = new System.Drawing.Size(220, 27);
            this.txtPassWord.TabIndex = 1;
            //
            // lblHienThiCaption
            //
            this.lblHienThiCaption.AutoSize = true;
            this.lblHienThiCaption.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblHienThiCaption.Location = new System.Drawing.Point(30, 80);
            this.lblHienThiCaption.Name = "lblHienThiCaption";
            this.lblHienThiCaption.Size = new System.Drawing.Size(80, 20);
            this.lblHienThiCaption.TabIndex = 2;
            this.lblHienThiCaption.Text = "Hiển Thị:";
            //
            // lblHienThi
            //
            this.lblHienThi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblHienThi.Location = new System.Drawing.Point(180, 77);
            this.lblHienThi.Name = "lblHienThi";
            this.lblHienThi.Size = new System.Drawing.Size(220, 27);
            this.lblHienThi.TabIndex = 3;
            this.lblHienThi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // btnHienThi
            //
            this.btnHienThi.Location = new System.Drawing.Point(30, 140);
            this.btnHienThi.Name = "btnHienThi";
            this.btnHienThi.Size = new System.Drawing.Size(100, 32);
            this.btnHienThi.TabIndex = 4;
            this.btnHienThi.Text = "Hiển Thị";
            this.btnHienThi.UseVisualStyleBackColor = true;
            this.btnHienThi.Click += new System.EventHandler(this.btnHienThi_Click);
            //
            // btnTiep
            //
            this.btnTiep.Location = new System.Drawing.Point(160, 140);
            this.btnTiep.Name = "btnTiep";
            this.btnTiep.Size = new System.Drawing.Size(100, 32);
            this.btnTiep.TabIndex = 5;
            this.btnTiep.Text = "Tiếp";
            this.btnTiep.UseVisualStyleBackColor = true;
            this.btnTiep.Click += new System.EventHandler(this.btnTiep_Click);
            //
            // btnDong
            //
            this.btnDong.Location = new System.Drawing.Point(290, 140);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(100, 32);
            this.btnDong.TabIndex = 6;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            //
            // Form1
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(450, 210);
            this.Controls.Add(this.lblNhapPassword);
            this.Controls.Add(this.txtPassWord);
            this.Controls.Add(this.lblHienThiCaption);
            this.Controls.Add(this.lblHienThi);
            this.Controls.Add(this.btnHienThi);
            this.Controls.Add(this.btnTiep);
            this.Controls.Add(this.btnDong);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sử Dụng Label & Textbox";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblNhapPassword;
        private System.Windows.Forms.TextBox txtPassWord;
        private System.Windows.Forms.Label lblHienThiCaption;
        private System.Windows.Forms.Label lblHienThi;
        private System.Windows.Forms.Button btnHienThi;
        private System.Windows.Forms.Button btnTiep;
        private System.Windows.Forms.Button btnDong;
    }
}
