using System;
using System.Windows.Forms;

namespace Bai1PasswordForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Nút "Hiển Thị"
        private void btnHienThi_Click(object sender, EventArgs e)
        {
            lblHienThi.Text = txtPassWord.Text;
        }

        // Nút "Tiếp"
        private void btnTiep_Click(object sender, EventArgs e)
        {
            lblHienThi.Text = "";
            txtPassWord.Clear();
            txtPassWord.Focus();
        }

        // Nút "Đóng"
        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
            // hoặc: Application.Exit();
        }

        // Sự kiện FormClosing - xác nhận trước khi đóng
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc bạn muốn đóng ứng dụng?", "Thông báo!",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);

            if (dl == DialogResult.No)
                e.Cancel = true;
        }
    }
}
